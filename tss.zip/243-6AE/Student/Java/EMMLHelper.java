package com.softwareag.training;

public class EMMLHelper {

  public String normalizeCountryName(String name) {
    name = name.trim().toLowerCase();
    StringBuilder nameBuilder = new StringBuilder();
    if (name.length() > 0) {
      String[] segmentArray = name.split(" ");
      for (String segment : segmentArray) {
        if (segment.trim().length() > 0) {
          char[] charArray = segment.trim().toCharArray();
          charArray[0] = Character.toUpperCase(charArray[0]);
          segment = new String(charArray);
          nameBuilder.append(segment).append(" ");
        }
      }
    }
    return nameBuilder.toString().trim();
  }
}
